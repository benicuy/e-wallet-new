package com.nexo.pay
import android.content.Intent; import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (AccountManager.isLogin(this)) { startActivity(Intent(this, MainActivity::class.java)); finish(); return }
        setContentView(R.layout.activity_login)
        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            val nomor = findViewById<EditText>(R.id.etNomorLogin).text.toString()
            val pin = findViewById<EditText>(R.id.etPinLogin).text.toString()
            if (AccountManager.login(this, nomor, pin)) { Toast.makeText(this, "Halo ${AccountManager.getNama(this)}!", Toast.LENGTH_SHORT).show(); startActivity(Intent(this, MainActivity::class.java)); finish() }
            else Toast.makeText(this, "Nomor / PIN Salah!", Toast.LENGTH_SHORT).show()
        }
        findViewById<TextView>(R.id.tvKeDaftar).setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
    }
}
