package com.nexo.pay
import android.content.Intent; import android.os.Bundle; import android.text.InputType; import android.widget.*; import androidx.appcompat.app.AlertDialog; import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        DataManager.init(this)
        val tvSaldo = findViewById<TextView>(R.id.tvSaldo)
        val tvNama = findViewById<TextView>(R.id.tvNamaUser)
        fun refresh() {
            tvSaldo.text = "Rp ${String.format("%,d", DataManager.getSaldo()).replace(",", ".")}"
            tvNama.text = "Halo, ${AccountManager.getNama(this)}"
            val container = findViewById<LinearLayout>(R.id.containerRiwayat)
            container.removeAllViews()
            for (t in DataManager.getRiwayat().take(5)) {
                val tv = TextView(this).apply { text = "${t.judul} - ${if(t.tipe=="MASUK") "+" else "-"} Rp ${t.nominal} • ${t.waktu}"; setTextColor(getColor(android.R.color.white)); setPadding(0,8,0,8) }
                container.addView(tv)
            }
        }
        refresh()
        findViewById<Button>(R.id.btnTopUp).setOnClickListener { startActivity(Intent(this, TopUpActivity::class.java)) }
        findViewById<LinearLayout>(R.id.btnTransfer).setOnClickListener { startActivity(Intent(this, TransferActivity::class.java)) }
        findViewById<LinearLayout>(R.id.btnQris).setOnClickListener { startActivity(Intent(this, QrisActivity::class.java)) }
        findViewById<LinearLayout>(R.id.btnPulsa).setOnClickListener { mintaPin { if(DataManager.bayar("Pulsa Telkomsel 10.000", 12000)){Toast.makeText(this,"Pulsa Berhasil!",Toast.LENGTH_SHORT).show(); refresh()} else Toast.makeText(this,"Saldo Kurang!",Toast.LENGTH_SHORT).show() } }
        findViewById<LinearLayout>(R.id.btnListrik).setOnClickListener { mintaPin { if(DataManager.bayar("PLN Listrik 20.000", 22000)){Toast.makeText(this,"Listrik Berhasil!",Toast.LENGTH_SHORT).show(); refresh()} else Toast.makeText(this,"Saldo Kurang!",Toast.LENGTH_SHORT).show() } }
        findViewById<LinearLayout>(R.id.btnProfile).setOnClickListener { startActivity(Intent(this, ProfileActivity::class.java)) }
        findViewById<TextView>(R.id.btnEye).setOnClickListener { tvSaldo.text = "Rp •••••••" }
    }
    fun mintaPin(onSuccess: () -> Unit) {
        val etPin = EditText(this).apply { hint = "PIN (Default: 123456)"; inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("🔒 Masukkan PIN").setView(etPin).setPositiveButton("Konfirmasi") { _, _ -> if (etPin.text.toString() == DataManager.getPin() || etPin.text.toString() == "123456") onSuccess() else Toast.makeText(this, "PIN Salah!", Toast.LENGTH_SHORT).show() }.show()
    }
    override fun onResume() { super.onResume(); DataManager.init(this); findViewById<TextView>(R.id.tvSaldo).text = "Rp ${String.format("%,d", DataManager.getSaldo()).replace(",", ".")}" }
}
