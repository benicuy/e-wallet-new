package com.nexo.pay
import android.content.Intent; import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.integration.android.IntentIntegrator
class QrisActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_qris); DataManager.init(this)
        findViewById<Button>(R.id.btnScan).setOnClickListener { IntentIntegrator(this).apply { setPrompt("Scan QRIS NEXO PAY"); setBeepEnabled(true); initiateScan() } }
        findViewById<Button>(R.id.btnBayarQris).setOnClickListener { if(DataManager.bayar("Bayar QRIS - Kopi Kenangan", 25000)) Toast.makeText(this,"Bayar QRIS Berhasil!",Toast.LENGTH_SHORT).show() else Toast.makeText(this,"Saldo Kurang!",Toast.LENGTH_SHORT).show() }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null && result.contents != null) Toast.makeText(this, "QR: ${result.contents}", Toast.LENGTH_LONG).show()
        super.onActivityResult(requestCode, resultCode, data)
    }
}
