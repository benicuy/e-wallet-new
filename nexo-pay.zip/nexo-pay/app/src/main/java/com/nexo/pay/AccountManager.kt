package com.nexo.pay
import android.content.Context
object AccountManager {
    private const val PREF = "NEXO_ACCOUNT"
    fun register(context: Context, nama: String, nomorHp: String, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (prefs.contains("user_$nomorHp")) return false
        prefs.edit().apply { putString("user_$nomorHp", "$nama|$pin"); putString("current_user", nomorHp); putString("current_nama", nama); putBoolean("is_login", true); apply() }
        context.getSharedPreferences("NEXO_PAY", Context.MODE_PRIVATE).edit().putInt("saldo", 50000).apply()
        return true
    }
    fun login(context: Context, nomorHp: String, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val data = prefs.getString("user_$nomorHp", null) ?: return false
        if (data.split("|")[1] == pin) {
            prefs.edit().apply { putString("current_user", nomorHp); putString("current_nama", data.split("|")[0]); putBoolean("is_login", true); apply() }
            return true
        }
        return false
    }
    fun isLogin(context: Context): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("is_login", false)
    fun getNama(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("current_nama", "User") ?: "User"
    fun getNomor(context: Context): String = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("current_user", "-") ?: "-"
    fun logout(context: Context) { context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean("is_login", false).apply() }
    fun gantiPin(context: Context, pinBaru: String) {
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        prefs.edit().putString("user_${getNomor(context)}", "${getNama(context)}|$pinBaru").apply()
    }
}
