package com.nexo.pay
import android.content.Intent; import android.os.Bundle; import android.text.InputType; import android.widget.*; import androidx.appcompat.app.AlertDialog; import androidx.appcompat.app.AppCompatActivity
class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_profile); DataManager.init(this)
        findViewById<TextView>(R.id.tvNamaProfil).text = AccountManager.getNama(this)
        findViewById<TextView>(R.id.tvNomorProfil).text = AccountManager.getNomor(this)
        findViewById<TextView>(R.id.tvSaldoProfil).text = "Saldo: Rp ${DataManager.getSaldo()}"
        findViewById<Button>(R.id.btnGantiPin).setOnClickListener {
            val et = EditText(this).apply { hint="PIN Baru 6 Digit"; inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
            AlertDialog.Builder(this).setTitle("Ganti PIN").setView(et).setPositiveButton("Simpan"){_,_-> AccountManager.gantiPin(this, et.text.toString()); Toast.makeText(this,"PIN Diganti!",Toast.LENGTH_SHORT).show()}.show()
        }
        findViewById<Button>(R.id.btnLogout).setOnClickListener { AccountManager.logout(this); startActivity(Intent(this, LoginActivity::class.java)); finishAffinity() }
    }
}
