package com.nexo.pay
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
data class Transaksi(val judul: String, val waktu: String, val nominal: Int, val tipe: String)
object DataManager {
    private lateinit var prefs: SharedPreferences
    fun init(context: Context) {
        prefs = context.getSharedPreferences("NEXO_PAY", Context.MODE_PRIVATE)
        if (!prefs.contains("saldo")) prefs.edit().putInt("saldo", 50000).apply()
    }
    fun getSaldo(): Int = prefs.getInt("saldo", 0)
    fun getPin(): String = prefs.getString("pin", "123456") ?: "123456"
    fun topUp(nominal: Int): Boolean {
        prefs.edit().putInt("saldo", getSaldo() + nominal).apply()
        simpanTransaksi("Top Up Saldo", nominal, "MASUK"); return true
    }
    fun bayar(judul: String, nominal: Int): Boolean {
        if (getSaldo() < nominal) return false
        prefs.edit().putInt("saldo", getSaldo() - nominal).apply()
        simpanTransaksi(judul, nominal, "KELUAR"); return true
    }
    private fun simpanTransaksi(judul: String, nominal: Int, tipe: String) {
        val list = getRiwayat().toMutableList()
        val waktu = java.text.SimpleDateFormat("dd MMM • HH:mm", java.util.Locale("id","ID")).format(java.util.Date())
        list.add(0, Transaksi(judul, waktu, nominal, tipe))
        val arr = JSONArray()
        for (t in list.take(50)) { val obj = JSONObject(); obj.put("judul", t.judul); obj.put("waktu", t.waktu); obj.put("nominal", t.nominal); obj.put("tipe", t.tipe); arr.put(obj) }
        prefs.edit().putString("riwayat", arr.toString()).apply()
    }
    fun getRiwayat(): List<Transaksi> {
        val json = prefs.getString("riwayat", "[]") ?: "[]"
        val arr = JSONArray(json); val list = mutableListOf<Transaksi>()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); list.add(Transaksi(o.getString("judul"), o.getString("waktu"), o.getInt("nominal"), o.getString("tipe"))) }
        return list
    }
}
