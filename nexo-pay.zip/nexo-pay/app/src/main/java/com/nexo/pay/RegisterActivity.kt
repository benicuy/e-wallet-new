package com.nexo.pay
import android.content.Intent; import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_register)
        findViewById<Button>(R.id.btnDaftar).setOnClickListener {
            val nama = findViewById<EditText>(R.id.etNama).text.toString()
            val nomor = findViewById<EditText>(R.id.etNomor).text.toString()
            val pin = findViewById<EditText>(R.id.etPin).text.toString()
            if (nama.isEmpty() || nomor.isEmpty() || pin.length != 6) { Toast.makeText(this, "Lengkapi semua, PIN 6 digit!", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            if (AccountManager.register(this, nama, nomor, pin)) { Toast.makeText(this, "Selamat Datang $nama! Bonus Rp 50.000", Toast.LENGTH_LONG).show(); startActivity(Intent(this, MainActivity::class.java)); finish() }
            else Toast.makeText(this, "Nomor udah terdaftar!", Toast.LENGTH_SHORT).show()
        }
        findViewById<TextView>(R.id.tvKeLogin).setOnClickListener { startActivity(Intent(this, LoginActivity::class.java)) }
    }
}
