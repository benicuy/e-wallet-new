package com.nexo.pay
import android.os.Bundle; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
class TopUpActivity : AppCompatActivity() {
    private var selectedNominal = 50000
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_topup); DataManager.init(this)
        val btns = listOf(R.id.btn10 to 10000, R.id.btn20 to 20000, R.id.btn50 to 50000, R.id.btn100 to 100000, R.id.btn200 to 200000, R.id.btn500 to 500000)
        for ((id, nominal) in btns) { findViewById<Button>(id).setOnClickListener { selectedNominal = nominal; Toast.makeText(this, "Pilih Rp $nominal", Toast.LENGTH_SHORT).show() } }
        findViewById<Button>(R.id.btnTopUpNow).setOnClickListener { DataManager.topUp(selectedNominal); Toast.makeText(this, "Top Up Rp $selectedNominal Berhasil!", Toast.LENGTH_SHORT).show(); finish() }
    }
}
