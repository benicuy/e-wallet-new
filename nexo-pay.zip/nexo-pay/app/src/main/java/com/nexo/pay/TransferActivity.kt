package com.nexo.pay
import android.os.Bundle; import android.text.Editable; import android.text.TextWatcher; import android.widget.*; import androidx.appcompat.app.AppCompatActivity
class TransferActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_transfer); DataManager.init(this)
        val etTujuan = findViewById<EditText>(R.id.etTujuan); val etNominal = findViewById<EditText>(R.id.etNominal); val tvBiaya = findViewById<TextView>(R.id.tvBiaya)
        etNominal.addTextChangedListener(object: TextWatcher {
            override fun afterTextChanged(s: Editable?) { val n = s.toString().toIntOrNull() ?: 0; val admin = if(n>=100000) 0 else 1000; tvBiaya.text = "Biaya Admin: Rp $admin | Total: Rp ${n+admin}" }
            override fun beforeTextChanged(a: CharSequence?, b:Int, c:Int, d:Int){} override fun onTextChanged(a: CharSequence?, b:Int, c:Int, d:Int){}
        })
        findViewById<Button>(R.id.btnKirim).setOnClickListener {
            val nominal = etNominal.text.toString().toIntOrNull() ?: 0; val admin = if(nominal>=100000) 0 else 1000; val total = nominal+admin
            if (DataManager.bayar("Transfer ke ${etTujuan.text} (Admin Rp $admin)", total)) { Toast.makeText(this, "Transfer Berhasil!", Toast.LENGTH_LONG).show(); finish() }
            else Toast.makeText(this, "Saldo Tidak Cukup!", Toast.LENGTH_SHORT).show()
        }
    }
}
